


Author:				Arun Donti
Date:				2/6/13
Project ID:			Lab 3
CS Class:			CS 2303
Programming Language:		C .


Problem Description:		Creating Event Queues




How to build the program:	make

How to run the prorgram ./main 10  <lab3.dat>Eventlist.txt

Program Source:			lab3.c

Additional Files:		lab3.h

